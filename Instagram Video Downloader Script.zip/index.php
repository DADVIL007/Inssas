<?php include("config.php"); ?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="<?php echo $config["description"]; ?>">
    <meta name="author" content="">

    <title>Instagram Downloader</title>

    <!-- Bootstrap core CSS -->
    <link href="content/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="content/css/landing-page.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <?php echo $config["ga"]; ?>

  </head>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4801949552977794"
     crossorigin="anonymous"></script>


  <body>

    <?php include '_nav.php'; ?>

    <section class="features-icons bg-light text-center">
      <div class="container">
        <div class="row">
          <?php get_ad("ad728"); ?>
          <div class="col-md-10 offset-md-1">
            <div class="col-md-6 mx-auto">
              <img src="content/img/insta.png" class="rounded img-fluid">
            </div>

            <h2 class="text-center mt-4 mb-4">Download Videos from Instagram </h2>

            <form method="POST" action="javascript:void(0)" id="form">
              <div class="download-input mb-4">
                <div class="input-group input-group-lg">
                  <input type="text" id="url" class="form-control" placeholder="Paste link here!">
                  <div class="input-group-append">
                    <button class="btn btn-blue" id="form_submit" type="submit">
                      <i class="fa fa-download" aria-hidden="true" style="color:white;background:transparent;margin: 4px;"></i>
                    </button>
                  </div>
                </div>
              </div>
            </form>
 
            <i class="fa fa-circle-o-notch fa-3x fa-spin mb-4" id="loading-ajax" style="display: none;"></i>

            <?php get_ad("ad468"); ?>

            <div id="downloadbox"></div>
            
             <h2 class="text-center mt-4 mb-4">This code designed by 👉 Saurabh Tiwari (techwithsaurbh1) </h2>

          </div>
        </div>
      </div>
    </section>

    <?php include '_body.php'; ?>
    <script src="content/js/ajax.js"></script>

  </body>

</html>
